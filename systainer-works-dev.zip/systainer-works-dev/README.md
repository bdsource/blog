# Systainer Works
http://systainer.works/

The purposes of Systainer Works is for the systainer community to share how they use systainers and to inspire new and existing systainer users on what the systainer can be used for and how to do a fitout.  #systainerfitout

This is a site...
* Built on Jekyll (static site)
* Hosted on Netlify


### Theme Details
The site is based on Jekyll Board theme.
https://jekyllthemes.io/theme/board-portfolio-jekyll-theme

Please note that if we have to revert to the source of the theme, there are some steps taken to update gem and gemlock file.  See PDF on email chain with theme designer.
